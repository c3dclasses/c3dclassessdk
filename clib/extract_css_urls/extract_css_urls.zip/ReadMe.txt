extract_css_urls.php
  David R. Nadeau
  NadeauSoftware.com

These files are distributed under a BSD license that enables you to use,
modify and redistribute this code as you see fit.  Please note the
copyright statement in the source code.

Please see the accompanying article:

http://nadeausoftware.com/articles/2008/01/php_tip_how_extract_urls_css_file
